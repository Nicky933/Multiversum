<?php include 'include/header_index.php'; ?>


<div class="sale_container">

    <?php sale($conn,$sale_item);?>

</div>
