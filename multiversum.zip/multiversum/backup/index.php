<?php
    include "includes/header_index.php";
?>

<div class="index"><br>
    <span class="index-Company">
        Multiversum
    </span><br><br><br>
    <span class="index-catalog">
        <a class="index-catalog" href="catalog.php?page=1">
            <div class="index-catalog">  Catalog <br>VR headsets</div>
        </a>
    </span><br>
    <span class="index-title">
       The number 1 VR headset shop for the best experience at home
    </span>
</div>
