<?php

$conn = mysqli_connect("sql5.pcextreme.nl", "82121multiversum", "multiversum", "82121multiversum");

if (mysqli_connect_errno()) {
printf("Connect failed: %s\n", mysqli_connect_error());
exit();
}
