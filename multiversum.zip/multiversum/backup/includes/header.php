<?php include "connect.php"; ?>
<!DOCTYPE html>
<html lang="en">


<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<meta name="description" content="Project Baksteen V2">
	<meta name="author" content="Floyd + Nicky">

	<title>Multiversum</title>

	<link href="css/style.css" rel="stylesheet">
</head>

<body>
<div class="top">
<span class="company">
        <a class="company" href="index.php">MULTIVERSUM</a>
    </span>
    <span class="nav">
        <a class="nav" href="../multiversum/catalog.php?page=1">Catalog</a>
         <a class="nav" style="float: right;" href="#">Shopping Cart (0)</a>
    </span>

</div>


