<?php

function products($conn,$page){
	$items_per_page = 6;
	$page_limit = ($page - 1) * $items_per_page;
    $id = 0;
    $name = 0;

	$producten_query = "SELECT id, name, price, description FROM catalog LIMIT $page_limit,$items_per_page";
	$producten_result = mysqli_query($conn,$producten_query) or die(mysqli_error($conn));
	$total_products = mysqli_num_rows($producten_result);
	$GLOBALS['total_products'] = $total_products;

	$i=0;



	if ($total_products > 0) {
		echo "<div class='Product_Catalog_row'>";
		while ($producten_array = mysqli_fetch_array($producten_result)) {
			$id = $producten_array['id'];
			$name = $producten_array['name'];
			$price = $producten_array['price'];
            $description = $producten_array['description'];
            $description = substr($description, 0, 50);
            $x = $i+1;
            $img = "img/VR-".$x.".jpeg";
			echo "<div class='product'>
					<span class='product_name'>
					 	<a class='product_name' href='product_detail.php?id=$id'>  $name </a>
					 </span>
					  <br>
					  <br>
					 <span class='product_description'><img class='product-img' src='$img' </span>
					 <br>
					 <span class='product_description'>$description</span>
					 <br><br>
					 <span class='product_price'><h4>Prijs : vanaf € $price</h4> </span>				 
					 <span class='product_cart'>
					    <button class='minus'> - </button>
					    <button class='plus'> + </button>	
					    <input type='text' class='total' value='0' size='1'> </span>	
				</div>";



			$i++;
		}
		if ($i % 3 == 0) {
			print '</div><br><br><div class="Product_Catalog_row">';
		}
	}

	else {
		echo "<div class='product'>
					<span class='product_name'>
					 	<a class='product_name' href='product_detail.php?id=$id'>  No products </a>
					 </span>
		</div>";
	}
	echo "</div>";
}

function products_details($conn,$id){

    $name = 0;

    $producten_query = "SELECT id, name, price, description FROM catalog where id = $id";
    $producten_result = mysqli_query($conn,$producten_query) or die(mysqli_error($conn));
    $total_products = mysqli_num_rows($producten_result);
    $GLOBALS['total_products'] = $total_products;

    $i=0;



    if ($total_products > 0) {
        echo "<div class='Product_Catalog_row'>";
        while ($producten_array = mysqli_fetch_array($producten_result)) {
            $id = $producten_array['id'];
            $name = $producten_array['name'];
            $price = $producten_array['price'];
            $description = $producten_array['description'];
            $x = $i+1;
            $img = "img/VR-".$x.".jpeg";
            echo "<div class='product'>
					<span class='product_name'>
					 	<a class='product_name' href='product_detail.php?id=$id'>  $name </a>
					 </span>
					  <br>
					  <br>
					 <span class='product_description'><img class='product-img' src='$img' </span>
					 <br>
					 <span class='product_description-details'>$description</span>
					 <br><br>
					 <span class='product_price'>Prijs : vanaf € $price </span>				 
					 <span class='product_cart'>
					    <button class='minus'> - </button>
					    <button class='plus'> + </button>	
					    <input type='text' class='total' value='0' size='1'> </span>	
				</div>";



            $i++;
        }
        if ($i % 3 == 0) {
            print '</div><br><br><div class="Product_Catalog_row">';
        }
    }

    else {
        echo "<div class='product'>
					<span class='product_name'>
					 	<a class='product_name' href='product_detail.php?id=$id'>  No products </a>
					 </span>
		</div>";
    }
    echo "</div>";
}

function products_upload($conn,$product_name,$product_price,$product_description){
    $last_id  = "";
$product_upload_insert = "INSERT INTO catalog (name,price,description) 
                          VALUES ('$product_name','$product_price','$product_description')";
$product_upload_result = mysqli_query($conn,$product_upload_insert) or die(mysqli_error($conn));

$last_id = mysqli_insert_id($conn);

if (!empty($last_id)){
    echo "Product upload was succesfull";
}
else {  echo "Product upload was not succesfull";}
}