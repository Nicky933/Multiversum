<?php include "connect.php"; ?>
<!DOCTYPE html>
<html lang="en">


<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<meta name="description" content="Project Baksteen V2">
	<meta name="author" content="Floyd + Nicky">

	<title>Multiversum</title>

	<link href="css/style.css" rel="stylesheet">
</head>


