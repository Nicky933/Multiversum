<?php
include "includes/header.php";
include "includes/functions.php";

if (isset($_POST['submit']))
{
    $product_name           =  $_POST['product_name'];
    $product_price          = $_POST['product_price'];
    $product_description    = $_POST['product_details'];

    products_upload($conn,$product_name,$product_price,$product_description);


}

?>
<form method="post" action="<?php echo $_SERVER['PHP_SELF'];?>">
    <div class="product_upload">
        Product Name : <input type="text" name="product_name">
        <br>
        Product Price : <input type="text" name="product_price">
        <br>
        Product details : <input type="text" name="product_details">
        <br>
        <input type="submit" name="submit" value="upload">
    </div>
</form>

<?php include "includes/footer.php"; ?>