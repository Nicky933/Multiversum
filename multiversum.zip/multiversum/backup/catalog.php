<?php
$page = $_GET['page'];
$page_limit = 0;

include "includes/header.php";
include "includes/functions.php";

?>
<div class="content">
<?php products($conn,$page); ?>
</div>
<div class="pages">
 <?php
 if ($page > 1){
     $previous_page = $page -1;
     echo "<a class='pages' href='catalog.php?page=$previous_page'>$previous_page </a>";
 }
 echo "&nbsp $page &nbsp";
 $next_page = $page +1;
 if ( $GLOBALS['total_products'] == 6){
     echo "<a class='pages' href='catalog.php?page=$next_page'>$next_page  </a>";
 }
 ?>

</div>

<?php include "includes/footer.php"; ?>