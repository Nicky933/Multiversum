<?php
$id = $_GET['id'];
$page_limit = 0;

include "includes/header.php";
include "includes/functions.php";

?>

<div class="product_detail">
<?php products_details($conn,$id); ?>
</div>


<?php include "includes/footer.php"; ?>