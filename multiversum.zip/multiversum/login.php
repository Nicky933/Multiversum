<?php
$page_name = "Login";
include 'include/header.php';

if (isset($_POST['submit']))
{
    $user = $_POST['user'];
    $ww = $_POST['ww'];

    login($conn,$user,$ww);
}

?>
<br><br>
<form action="<?php $_SERVER['PHP_SELF']; ?>" method="post">
    <div class='product_container'>
        <span class='product_title'> Gebruikersnaam </span>
        <span class='product_input'>
                           <input class='product' type='text' name='user' value=''>
                        </span>
        <br>
        <span class='product_title'> Wachtwoord </span>
        <span class='product_input'>
                           <input class='product' type='password' name='ww' value=''>
                        </span>
        <br>
        <input class='button_product' type='submit' name='submit' value='Login'><br><br>

    </div>
</form>
