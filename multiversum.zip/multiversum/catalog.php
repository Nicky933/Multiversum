<?php
$page_name = "catalogus";

if (!isset($_GET['page'])){
    $page = 1;
}
else{
    $page = $_GET['page'];
}

if (!isset($_GET['filter']))
{
    $filter = "name";
    $sort = "ASC";
}
else {
    $filter = $_GET['filter'];
    $sort = $_GET['sort'];
}
if (isset($_GET['search']))
{
    $search = $_GET['search'];
}
else { $search = NULL;}

if (isset($_POST['add_to_cart']))
{
    echo "<script type='text/javascript'>alert('Product toegevoegd aan winkelwagen')</script>";
}
$page_limit = 0;
include 'include/header.php';

$count_sale         = "SELECT id FROM catalog";
$count_sale_result  = mysqli_query($conn,$count_sale) or die(mysqli_error($conn));
$total_sale         = mysqli_num_rows($count_sale_result);

$total = round($total_sale /6);



?>
<div class="content">
    <?php catalog($conn,$page,$filter,$sort,$search); ?>
</div>

<div class="pages">
    <?php

    for ($i=1; $i <= $total; $i++)
        {
            if ($i == $page)
            {
                $page_button =  "<span class='active'>$i </span>";
            }
            else {
                $page_button =  "<span class='deactive'>$i </span>";
            }
            if ($search == NULL){
                echo "<a class='pages' href='catalog.php?page=$i&filter=$filter&sort=$sort'> $page_button </a>";
            }
            else {
                echo "<a class='pages' href='catalog.php?page=$i&filter=$filter&sort=$sort&search=$search'> $page_button </a>";

            }
        }



    ?>

</div>
