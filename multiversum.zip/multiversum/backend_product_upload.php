<?php
$page_name = "Nieuw Product";
include 'include/header_backend.php';
if (isset($_POST['submit']))
{






    products_upload($conn);


}

?>
    <form method="post" action="<?php echo $_SERVER['PHP_SELF'];?>" enctype="multipart/form-data">
    <hr class="color_top">
    <div class="mid">
        <span class="mid-title"><?php echo $page_name ; ?></span> <input class="button_mid" type="submit" name="submit" value="Upload nieuw product" > <br>
    </div>
    <hr class="color_bottom">

<div class="upload">

    <div class='product_container'>
        <span class='product_title'> Product Naam </span>
        <span class='product_input'>
                           <input class='product' type='text' name='product_name' value=''>
                        </span>
        <br>
        <span class='product_title'> Product omschrijving </span>
        <span class='product_input'>
                            <textarea class='product' name='product_desc'></textarea>
                        </span>
        <br>
        <span class='product_title'> Product prijs </span>
        <span class='product_input'>
                             <input class='product_price' type='text' name='product_price' value=''>
                        </span>
        <br>
        <span class='product_title'> Product sale </span>
        <span class='product_input'>
                           <input class='product_check' type='checkbox' name='product_sale' value="1">
                        </span>
        <br>
        <span class='product_title'> Product sale prijs</span>
        <span class='product_input'>
                           <input class='product_price' type='text' name='product_sale_price' value=''>
                        </span>
        <br>
        <span class='product_title'> Product Voorraad</span>
        <span class='product_input'>
                           <input class='product' type='text' name='product_stock' value=''>
                        </span>


    <span class='product_title'>    Upload Image</span>
    <span class='product_input'>
        <input type="file" name="product_image" id="fileToUpload">
    </span>
        <br><br>
        <span class='product_title'> <b>Specificaties</b>  </span> <br><br>
            <span class='product_title'> Artikelnummer </span>
            <span class='product_input'>
                           <input class='product' type='text' name='Artikelnummer' value=''>
                        </span>
            <br>
            <span class='product_title'> Fabrikantcode </span>
            <span class='product_input'>
                           <input class='product' type='text' name='fabrikantcode' value=''>
                        </span>
            <br>
            <span class='product_title'>Merk </span>
            <span class='product_input'>
                             <input class='product_price' type='text' name='merk' value=''>
                        </span>
            <br>
            <span class='product_title'> Garantier</span>
            <span class='product_input'>
                           <input class='product_price' type='text' name='garantie' value=''>
                        </span>
            <br>
            <span class='product_title'> Garantietype</span>
            <span class='product_input'>
                           <input class='product' type='text' name='garantietype' value=''>
                        </span>
            <br>
            <span class='product_title'> Compatable pc</span>
            <span class='product_input'>
                           <input class='product' type='text' name='compatable pc' value=''>
                        </span>
            <br>
            <span class='product_title'>Compatable smartphone</span>
            <span class='product_input'>
                           <input class='product' type='text' name='compatable_smartphone' value=''>
                        </span>
            <br>
            <span class='product_title'> Scherm</span>
            <span class='product_input'>
                           <input class='product' type='text' name='scherm' value=''>
                        </span>
            <br>
            <span class='product_title'> Verversingssnelheid</span>
            <span class='product_input'>
                           <input class='product' type='text' name='verversingssnelheid' value=''>
                        </span>
            <br>
            <span class='product_title'> Gezichtsveld</span>
            <span class='product_input'>
                           <input class='product' type='text' name='gezichtsveld' value=''>
                        </span>
            <br>
            <span class='product_title'> Verstelbaar</span>
            <span class='product_input'>
                           <input class='product' type='text' name='verstelbaar' value=''>
                        </span>
            <br>
            <span class='product_title'> Speakers</span>
            <span class='product_input'>
                           <input class='product' type='text' name='speakers' value=''>
                        </span>
            <br>
            <span class='product_title'> Rotatie tracking</span>
            <span class='product_input'>
                           <input class='product' type='text' name='rotatie_tracking' value=''>
                        </span>
            <br>
            <span class='product_title'> Positie tracking</span>
            <span class='product_input'>
                           <input class='product' type='text' name='positie_tracking' value=''>
                        </span>
            <br>
            <span class='product_title'> Kamergrote tracking</span>
            <span class='product_input'>
                           <input class='product' type='text' name='kamergrote_tracking' value=''>
                        </span>
            <br>
            <span class='product_title'> Controller inbegrepen</span>
            <span class='product_input'>
                           <input class='product' type='text' name='controller_inbegrepen' value=''>
                        </span>
            <br>
            <span class='product_title'> Motion control</span>
            <span class='product_input'>
                           <input class='product' type='text' name='motion_control' value=''>
                        </span>
            <br>
            <span class='product_title'> Haptic feedback</span>
            <span class='product_input'>
                           <input class='product' type='text' name='haptic_feedback' value=''>
                        </span>
            <br>
            <span class='product_title'> Brill vriendelijk</span>
            <span class='product_input'>
                           <input class='product' type='text' name='brill_vriendelijk' value=''>
                        </span>
            <br>
            <span class='product_title'> Oogkussen</span>
            <span class='product_input'>
                           <input class='product' type='text' name='oogkussen' value=''>
                        </span>
            <br>
            <span class='product_title'> Vervangbaar oogkussen</span>
            <span class='product_input'>
                           <input class='product' type='text' name='vervangbaar_oogkussen' value=''>
                        </span>
            <br>
            <span class='product_title'> Hoofdband</span>
            <span class='product_input'>
                           <input class='product' type='text' name='hoofdband' value=''>
                        </span>
            <br>



        </div>
    </form>
    </div>
<BR><BR>
</form>
</div>

<?php include "include/footer.php"; ?>