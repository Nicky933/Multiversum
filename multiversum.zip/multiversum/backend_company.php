<?php
$page_name = "Over ons";
include 'include/header_backend.php';

if (isset($_POST['submit']))
{
    $name = $_POST['company_name'];
    $description = $_POST['company_desc'];
    $company_street = $_POST['company_street'];
    $company_number = $_POST['company_number'];
    $company_zip = $_POST['company_zip'];
    $company_city = $_POST['company_city'];
    $company_state = $_POST['company_state'];
    $company_land = $_POST['company_land'];

    company_info_update($conn,$name,$description,$company_street,$company_number,$company_zip,$company_city,$company_state,$company_land);
}

?>
<form action="<?php $_SERVER['PHP_SELF']; ?>" method="post">
    <hr class="color_top">
    <div class="mid">
        <span class="mid-title"><?php echo $page_name ; ?></span> <input class="button_mid" type="submit" name="submit" value="Update alle wijzigingen" > <br>
    </div>
    <hr class="color_bottom">

<div class="company_info">
<?php company_info_backend($conn); ?>
</div>
<br><br><br>
<hr class="color_bottom">
</
</form>

