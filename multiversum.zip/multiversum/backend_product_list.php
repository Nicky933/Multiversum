<?php
$page_name = 'Producten in catalogus';

include 'include/header_backend.php';


if (isset($_POST['spec'])){
    echo 'specificatie'; // nog niets doen
}

if (isset($_POST['one_product'])){
    $product_sale  = 0;
    $product_id             =  $_POST['product_id'];
    $product_name           = $_POST['product_name'];
    $product_price          = $_POST['product_price'];
    $product_desc           = $_POST['product_desc'];
    $product_stock          = $_POST['product_stock'];
    $product_sale_price     = $_POST['product_price_sale'];
    $product_image          = $_FILES["product_image"]["name"];
    $img_backup            =  $_POST['img_backup'];
    if  (isset($_POST['product_sale'])) {$product_sale = 1;} else {$product_sale = 0;}


    one_product_update($conn,$product_id, $product_name,$product_sale, $product_price, $product_desc, $product_image, $product_stock,$product_sale_price,$img_backup);
}

if (isset($_POST['delete_product'])){
    $product_id =  $_POST['product_id'];
    delete_product($conn,$product_id);
}


?><form action="<?php $_SERVER['PHP_SELF']; ?>" method="post">
<hr class="color_top">
<div class="mid">
    <span class="mid-title"><?php echo $page_name ; ?></span>  <br>
</div>
<hr class="color_bottom">
</form>

<?php
$product_select = "SELECT * FROM catalog";
$product_result = mysqli_query($conn, $product_select) or die(mysqli_error($conn));
$product_total = mysqli_num_rows($product_result);
$i = 0;
$x = 1;
if ($product_total > 0) {
while ($product_array = mysqli_fetch_array($product_result)) {
$id = $product_array['id'];
$name = $product_array['name'];
$price = $product_array['price'];
$description = $product_array['description'];
$img_server = $product_array['image'];
$sale_price = $product_array['sale_price'];
$stock = $product_array['stock'];
$img = "image/$img_server";
$product_sale = $product_array['sale'];

if ($product_sale == 1 ) {
    $check = "checked";
}
else {$check = "";}

echo "
<form method='post' enctype='multipart/form-data'  action=' " . $_SERVER['PHP_SELF'] . " ' >
<div class='product_img'> <img class='product_img' src='$img'>  </div>
<div class='product_button'> <br><br>

    <!-- <input class='button_product' type='submit' name='spec' value='Specificaties' ><br><br> -->

    <input class='button_product' type='submit' name='one_product' value='Update product'><br><br>

    <input class='button_product' type='submit' name='delete_product' value='Verwijder product' >
</div> <br>
<div class='product_container'>
    <span class='product_title'> Product Naam </span>
    <span class='product_input'>
                           <input class='product' type='text' name='product_name' value='$name'>  
                        </span>
    <br>
    <span class='product_title'> Product omschrijving </span>
    <span class='product_input'> 
                            <textarea class='product' name='product_desc'>$description</textarea>  
                        </span>
    <br>
    <span class='product_title'> Product prijs </span>
    <span class='product_input'> 
                             <input class='product_price' type='text' name='product_price' value='$price'>  
                        </span>
    <br>
    <span class='product_title'> Product sale </span>
    <span class='product_input'>
                           <input class='product_check' type='checkbox' name='product_sale' $check>  
                        </span>
    <br>
    <span class='product_title'> Product sale prijs</span>
    <span class='product_input'> 
                           <input class='product_price' type='text' name='product_price_sale' value='$sale_price'>  
                        </span>
    <br>
    <span class='product_title'> Product Voorraad</span>
    <span class='product_input'>
                           <input class='product' type='text' name='product_stock' value='$stock'>  
                        </span>
    <br>
    <span class='product_title'>    Upload Image</span>
    <span class='product_input'>
                            <input type='file' name='product_image' id='product_image_upload'>
                         </span>
    <input class='product' type='hidden' name='product_id' value='$id'>
    <input class='product' type='hidden' name='img_backup' value='$img_server'>
</div>

<hr class='color_mid'> 
";
$i++;
echo "</form>";
}

}

