<?php

$id = $_GET['id'];

include "include/header.php";

?>


<?php products_details($conn,$id); ?>

<?php products_specs($conn,$id); ?>


<?php include "include/footer.php"; ?>