<?php
$page_name = "Over ons";
include 'include/header.php';

?>

<div class="company_info">
<?php company_info($conn); ?>
</div>
<hr class="color_bottom">


