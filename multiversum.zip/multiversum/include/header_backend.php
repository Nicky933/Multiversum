<?php
include "connect.php";
include "functions.php";


?>
<!DOCTYPE html>
<html lang="en">


<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="Project Baksteen V2">
    <meta name="author" content="Floyd + Nicky">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Multiversum : Beheer omgeving</title>

    <link href="css/stylesheet_backend.css" rel="stylesheet">
</head>
<body>
    <div class="title_container">
      <a href="index.php">  <img class="logo" src="image/logo.svg"></a>
    </div>
    <div class="navigation">
       <a class="one" href="backend_product_list.php">  <span class="navigation"> <font color="#F1C40F"><b>P</b></font>roducten</span></a>
        <a class="two" href="backend_product_upload.php"> <span class="navigation"> <font color="#1ABC9C"><b>N</b></font>ieuw product</span></a>
            <a class="three" href="backend_company.php"> <span class="navigation"> <font color="#2C3E50"><b>I</b></font>nfo</span></a>
    </div>

