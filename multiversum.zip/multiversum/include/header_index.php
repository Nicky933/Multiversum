<?php
include "include/connect.php";
if (!isset($_POST['sale_item'])) {$sale_item = 1;}
else {$sale_item = $_POST['sale_item'];
}
include "functions.php";

?>
<!DOCTYPE html>
<html lang="en">


<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="Project Baksteen V2">
    <meta name="author" content="Floyd + Nicky">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Multiversum</title>

    <link href="css/stylesheet_index.css" rel="stylesheet">
</head>
<body>
<div class="title_container">
    <img class="logo" src="image/logo.svg">
</div>
<div class="navigation">
    <a class="one" href="catalog.php">  <span class="navigation"> <font color="#F1C40F"><b>C</b></font>atalogus</span></a>
    <a class="two" href="#"> <span class="navigation"> <font color="#1ABC9C"><b>W</b></font>inkelwagen</span></a>
    <a class="three" href="company.php"> <span class="navigation"> <font color="#2C3E50"><b>I</b></font>nfo</span></a>
    <a class="one" href="login.php">  <span class="navigation"> <font color="#F1C40F"><b>L</b></font>ogin</span></a>
</div>
<hr class="color_top">
<div class="mid">
    <?php company_title($conn); ?>
</div>
<hr class="color_bottom">


