<?php
//index
function company_title($conn)
{

    $company_title_sql = "SELECT company_name, company_desc FROM company";
    $company_title_result = mysqli_query($conn, $company_title_sql) or die(mysqli_error($conn));

    $company_title_array = mysqli_fetch_array($company_title_result);
    $name = $company_title_array['company_name'];
    $description = $company_title_array['company_desc'];

    echo " <span class='mid-title'> $name </span> <br>
    $description";


}

function login($conn,$user,$ww){

    $login_query = "SELECT login_id FROM login WHERE login_username = '$user' AND login_pass = '$ww'";
    $login_result = mysqli_query($conn, $login_query) or die(mysqli_error($conn));
    $login = mysqli_num_rows($login_result);

    if ($login > 0){
        echo "<meta http-equiv='refresh' content='0;url=backend_product_list.php'>";
    }
    else { echo "foutieve inloggegevens";}
}

function sale($conn)
{

    $count_sale = "SELECT id FROM catalog where sale = '1'";
    $count_sale_result = mysqli_query($conn, $count_sale) or die(mysqli_error($conn));
    $total_sale = mysqli_num_rows($count_sale_result);

    $sale_select = "SELECT * FROM catalog where sale = '1' LIMIT 3";
    $sale_result = mysqli_query($conn, $sale_select) or die(mysqli_error($conn));
    $sale_num = mysqli_num_rows($sale_result);
    $x = 1;
    if ($sale_num > 0) {
        while ($sale_array = mysqli_fetch_array($sale_result)) {
            $id = $sale_array['id'];
            $name = $sale_array['name'];
            $price = $sale_array['price'];
            $description = $sale_array['description'];
            $img = $sale_array['image'];
            $sale_price = $sale_array['sale_price'];
            $description = substr($description, 0, 100);
            $img = "image/$img";

            if ($x == 1) {
                $number = 'one';
            } else if ($x == 2) {
                $number = 'two';
            } else {
                $number = 'three';
            }


            echo "<div class='sale'><span class='sale'> sale</span>
<br>";
            echo "<div class='sale_image'><img class='sale_image' src='$img'>  </div>";
            echo "<div class='product'> 
                    <span class='sale_name'><a class='$number' href='product_details.php?id=$id'> $name </a></span> <br>
                     <span class='sale_desc'> $description</span> <br>
                    <span class='price'>  Van € $price voor <b class='sale_price'> € $sale_price </b></span> <br>
                  
                  </div>";
            echo "</div>";
            $x++;
        }

    }


}

// Frontend
function catalog($conn, $page, $filter, $sort,$search)
{
    $items_per_page = 6;
    $page_limit = ($page - 1) * $items_per_page;
    $id = 0;
    $name = 0;
    if ($search == NULL) {
        $producten_query = "SELECT * FROM catalog  ORDER BY $filter $sort  LIMIT $page_limit,$items_per_page";

    }
    else {
        $producten_query = "SELECT * FROM catalog WHERE name  LIKE '%$search%' ORDER BY $filter $sort  LIMIT $page_limit,$items_per_page";
    }

    $producten_result = mysqli_query($conn, $producten_query) or die(mysqli_error($conn));
    $total_products = mysqli_num_rows($producten_result);
    $GLOBALS['total_products'] = $total_products;

    $i = 0;

    $filter_name = 'name';
    $filter_price = 'price';
    $filter_sale = 'sale';
    if ($sort == 'ASC') {
        $sort_new = 'DESC';
        $symbol = '⬇';
    } else {
        $sort_new = 'ASC';
        $symbol = '⬆';
    }


    if ($total_products > 0) {
        echo "<form method='post' action='catalog.php?page=$page&filter=$filter_name&sort=$sort'>";
        echo "<div class='Product_Catalog_row'>
		<div class='filter'>
					<a class='one' href='catalog.php?page=$page&filter=$filter_name&sort=$sort'> Name  </a>
					<a class='two' href='catalog.php?page=$page&filter=$filter_price&sort=$sort'> Price   </a>
					<a class='three' href='catalog.php?page=$page&filter=$filter_sale&sort=DESC'> Sale   </a>
					<a class='onema' href='catalog.php?page=$page&filter=$filter&sort=$sort_new'> ($symbol)   </a>
		 </div>";
        while ($producten_array = mysqli_fetch_array($producten_result)) {
            $id = $producten_array['id'];
            $name = $producten_array['name'];
            $price = $producten_array['price'];
            $description = $producten_array['description'];
            $img = $producten_array['image'];
            $description = substr($description, 0, 50);
            $sale = $producten_array['sale'];
            $sale_price = $producten_array['sale_price'];
            $x = $i + 1;
            if ($x == 1 or $x == 4) {
                $number = 'one';
            } else if ($x == 2 or $x == 5) {
                $number = 'two';
            } else {
                $number = 'three';
            }
            $img = "image/$img";
            if ($sale == 1) {
                $sale_item = "<span class='sale'> sale</span>";
                $price = " Van € $price voor <b class='sale_price'> € $sale_price </b>";
            } else {
                $sale_item = "<span class='No_sale'> &nbsp;</span>";
                $price = "Prijs € $price ";

            }

            echo "<div class='sale'>$sale_item";
            echo "<div class='catalog_image'><img class='catalog_image' src='$img'>  </div>";
            echo "<div class='product'> 
                    <span class='catalog_name'> <a class='$number' href='product_details.php?id=$id'> $name  </a> </span> <br>
                     <span class='catalog_desc'> $description</span> <br>
                     <span class='catalog_price'> $price </span>
                     <span class='catalog_cart'>   <button class='catalog_cart'  type='submit' name='add_to_cart' value='$id' style='background:none;border:none;padding:0'> 🛒 </button> </span>  
                  </div>";
            echo "</div>";
            $i++;
        }
        if ($i % 3 == 0) {
            print '</div><br><br><div class="Product_Catalog_row">';
        }
    } else {
        echo "<div class='product'>
					<span class='catalog_name'>
					   Geen producten 
					 </span>
		</div>";
    }


}

/*backend
function product_list($conn)
{

    $product_select = "SELECT * FROM catalog";
    $product_result = mysqli_query($conn, $product_select) or die(mysqli_error($conn));
    $product_total = mysqli_num_rows($product_result);
    $i = 0;
    $x = 1;
    if ($product_total > 0) {
        while ($product_array = mysqli_fetch_array($product_result)) {
            $id = $product_array['id'];
            $name = $product_array['name'];
            $price = $product_array['price'];
            $description = $product_array['description'];
            $img = $product_array['image'];
            $sale_price = $product_array['sale_price'];
            $stock = $product_array['stock'];
            $img = "image/$img";

            echo "
  <form action=' " . $_SERVER['PHP_SELF'] . "' method='post' >
  <div class='product_img'> <img class='product_img' src='$img'>  </div>
   <div class='product_button'> <br><br>

   <!-- <input class='button_product' type='submit' name='spec' value='Specificaties' ><br><br> -->

       <input class='button_product' type='submit' name='one_product' value='Update product'><br><br>

        <input class='button_product' type='submit' name='delete_product' value='Verwijder product' >
    </div> <br>
                    <div class='product_container'>
                        <span class='product_title'> Product Naam </span>
                        <span class='product_input'>
                           <input class='product' type='text' name='product_name' value='$name'>
                        </span>
                            <br>
                        <span class='product_title'> Product omschrijving </span>
                        <span class='product_input'>
                            <textarea class='product' name='product_desc'>$description</textarea>
                        </span>
                          <br>
                        <span class='product_title'> Product prijs </span>
                        <span class='product_input'>
                             <input class='product_price' type='text' name='product_price' value='$price'>
                        </span>
                          <br>
                        <span class='product_title'> Product sale </span>
                        <span class='product_input'>
                           <input class='product_check' type='checkbox' name='product_sale'>
                        </span>
                          <br>
                        <span class='product_title'> Product sale prijs</span>
                        <span class='product_input'>
                           <input class='product_price' type='text' name='product_price_sale' value='$sale_price'>
                        </span>
                           <br>
                        <span class='product_title'> Product Voorraad</span>
                        <span class='product_input'>
                           <input class='product' type='text' name='product_stock' value='$stock'>
                        </span>
                             <br>
                              <span class='product_title'>    Upload Image</span>
                            <span class='product_input'>
                            <input type='file' name='product_image' id='fileToUpload'>
                         </span>
                          <input class='product' type='hidden' name='product_id' value='$id'>
                     <input class='product' type='hidden' name='img_backup' value='$img'>
                    </div>

                    <hr class='color_mid'> </form>
                        ";
            $i++;

        }

    }
}
*/

function delete_product($conn, $product_id)
{

    $delete_product = "delete FROM catalog where id ='$product_id'";
    $delete_entry = mysqli_query($conn, $delete_product) or die(mysqli_error($conn));

}


function products_details($conn, $id)
{


    $product_select = "SELECT * FROM catalog where id = '$id' ";
    $product_result = mysqli_query($conn, $product_select) or die(mysqli_error($conn));
    $product_total = mysqli_num_rows($product_result);

    if ($product_total > 0) {
        while ($product_array = mysqli_fetch_array($product_result)) {
            $id = $product_array['id'];
            $name = $product_array['name'];
            $price = $product_array['price'];
            $description = $product_array['description'];
            $img = $product_array['image'];
            $sale = $product_array['sale'];
            $sale_price = $product_array['sale_price'];
            $stock = $product_array['stock'];
            $img = "image/$img";

            if ($sale == 1) {
                $sale_item = "<span class='sale'> sale</span>";
                $price = " Van € $price voor <b class='sale_price'> € $sale_price </b>";
            } else {
                $sale_item = "<span class='No_sale'> &nbsp;</span>";
                $price = "Prijs € $price ";

            }

            echo "  
               <div class='product_detail_show'>
                  <br>

            
                <span class='product_detail_description'><img class='product-detail-picture' src='$img' </span>
                  <span class='product_detail_name'>
                    <br>
                   $name $sale_item 
                    <br>
                   <span class='product_details_price'> $price </span>
                  </span>
                 
                
                 <br> 
                 
                 <h3> Omschrijving </h3>
                  <div class=''>
                   <span class='product_description-details'>$description</span>
                 </div><br>

     

            </div>
            
            ";
        }
    }
}

function products_specs($conn, $id)
{


    $product_specs_select = "SELECT * FROM specs where product_id = '$id' ";
    $product_specs_result = mysqli_query($conn, $product_specs_select) or die(mysqli_error($conn));
    $product_specs_total = mysqli_num_rows($product_specs_result);

    if ($product_specs_total > 0) {
       $product_specs_array = mysqli_fetch_array($product_specs_result);

        $id = $product_specs_array['id'];
        $Artikelnummer = $product_specs_array['Artikelnummer'];
        $fabrikantcode = $product_specs_array['fabrikantcode'];
        $merk = $product_specs_array['merk'];
        $garantie = $product_specs_array['garantie'];
        $garantietype = $product_specs_array['garantietype'];
        $compatable_pc = $product_specs_array['compatable_pc'];
        $compatable_smartphone = $product_specs_array['compatable_smartphone'];
        $scherm = $product_specs_array['scherm'];
        $verversingssnelheid = $product_specs_array['verversingssnelheid'];
        $gezichtsveld = $product_specs_array['gezichtsveld'];
        $verstelbaar = $product_specs_array['verstelbaar'];
        $speakers = $product_specs_array['speakers'];
        $rotatie_tracking = $product_specs_array['rotatie_tracking'];
        $positie_tracking = $product_specs_array['positie_tracking'];
        $kamergrote_tracking = $product_specs_array['kamergrote_tracking'];
        $controller_inbegrepen = $product_specs_array['controller_inbegrepen'];
        $motion_control = $product_specs_array['motion_control'];
        $haptic_feedback = $product_specs_array['haptic_feedback'];
        $brill_vriendelijk = $product_specs_array['brill_vriendelijk'];
        $oogkussen = $product_specs_array['oogkussen'];
        $vervangbaar_oogkussen = $product_specs_array['vervangbaar_oogkussen'];
        $hoofdband = $product_specs_array['hoofdband'];


            echo "    <div class='product_container'>
                        <span class='product_title'> Artikelnummer </span>
                        <span class='product_input'>
                         $Artikelnummer
                        </span>
                            <br>
                        <span class='product_title'> fabrikantcode </span>
                        <span class='product_input'>
                         $fabrikantcode
                        </span>
                          <br>
                        <span class='product_title'> merk </span>
                        <span class='product_input'> 
                          $merk 
                        </span>
                          <br>             
                        <span class='product_title'> garantier</span>
                        <span class='product_input'> 
                         $garantie
                        </span>
                           <br>
                        <span class='product_title'> garantietype</span>
                        <span class='product_input'>
                         $garantietype
                        </span>
                         <br>
                              <span class='product_title'> compatable_pc</span>
                          <span class='product_input'>
                         $compatable_pc
                        </span>
                         <br>
                              <span class='product_title'>compatable_smartphone</span>
                          <span class='product_input'>
                       $compatable_smartphone  
                        </span>
                         <br>
                          <span class='product_title'> scherm</span>
                          <span class='product_input'>
                        $scherm
                        </span>
                         <br>
                          <span class='product_title'> verversingssnelheid</span>
                          <span class='product_input'>
                        $verversingssnelheid 
                        </span>
                         <br>
                          <span class='product_title'> gezichtsveld</span>
                          <span class='product_input'>
                        $gezichtsveld
                        </span>
                         <br>
                          <span class='product_title'> verstelbaar</span>
                          <span class='product_input'>
                        $verstelbaar 
                        </span>
                         <br>
                          <span class='product_title'> speakers</span>
                          <span class='product_input'>
                          $speakers  
                        </span>
                         <br>
                          <span class='product_title'> rotatie_tracking</span>
                          <span class='product_input'>
                          $rotatie_tracking 
                        </span>
                         <br>
                          <span class='product_title'> positie_tracking</span>
                          <span class='product_input'>
                          $positie_tracking
                        </span>
                         <br>
                          <span class='product_title'> kamergrote_tracking</span>
                          <span class='product_input'>
                          $kamergrote_tracking
                        </span> 
                        <br>
                          <span class='product_title'> controller_inbegrepen</span>
                          <span class='product_input'>
                          $controller_inbegrepen 
                        </span>
                         <br>
                          <span class='product_title'> motion_control</span>
                          <span class='product_input'>
                           $motion_control
                        </span>
                         <br>
                          <span class='product_title'> haptic_feedback</span>
                          <span class='product_input'>
                        $haptic_feedback
                        </span>
                         <br>
                          <span class='product_title'> brill_vriendelijk</span>
                          <span class='product_input'>
                         $brill_vriendelijk
                        </span>
                         <br>
                          <span class='product_title'> oogkussen</span>
                          <span class='product_input'>
                           $oogkussen
                        </span>
                         <br>
                          <span class='product_title'> vervangbaar_oogkussen</span>
                          <span class='product_input'>
                         $vervangbaar_oogkussen
                        </span>
                         <br>
                          <span class='product_title'> hoofdband</span>
                          <span class='product_input'>
                          $hoofdband
                        </span>
                        

            
                         
                    </div> 
             
            
            <hr class='color_bottom'>";
        }
        else { echo "<div class='product_container'><b>geen specs beschikbaar</b> </div><hr class='color_bottom'>";}

}

function products_spec_update($conn, $id)
{


    $product_specs_select = "SELECT * FROM specs where product_id = '$id' ";
    $product_specs_result = mysqli_query($conn, $product_specs_select) or die(mysqli_error($conn));
    $product_specs_total = mysqli_num_rows($product_specs_result);

    if ($product_specs_total > 0) {
        $product_specs_array = mysqli_fetch_array($product_specs_result);

        $id = $product_specs_array['id'];
        $Artikelnummer = $product_specs_array['Artikelnummer'];
        $fabrikantcode = $product_specs_array['fabrikantcode'];
        $merk = $product_specs_array['merk'];
        $garantie = $product_specs_array['garantie'];
        $garantietype = $product_specs_array['garantietype'];
        $compatable_pc = $product_specs_array['compatable_pc'];
        $compatable_smartphone = $product_specs_array['compatable_smartphone'];
        $scherm = $product_specs_array['scherm'];
        $verversingssnelheid = $product_specs_array['verversingssnelheid'];
        $gezichtsveld = $product_specs_array['gezichtsveld'];
        $verstelbaar = $product_specs_array['verstelbaar'];
        $speakers = $product_specs_array['speakers'];
        $rotatie_tracking = $product_specs_array['rotatie_tracking'];
        $positie_tracking = $product_specs_array['positie_tracking'];
        $kamergrote_tracking = $product_specs_array['kamergrote_tracking'];
        $controller_inbegrepen = $product_specs_array['controller_inbegrepen'];
        $motion_control = $product_specs_array['motion_control'];
        $haptic_feedback = $product_specs_array['haptic_feedback'];
        $brill_vriendelijk = $product_specs_array['brill_vriendelijk'];
        $oogkussen = $product_specs_array['oogkussen'];
        $vervangbaar_oogkussen = $product_specs_array['vervangbaar_oogkussen'];
        $hoofdband = $product_specs_array['hoofdband'];


        echo "    <div class='product_container'>
                        <span class='product_title'> Artikelnummer </span>
                        <span class='product_input'>
                           <input class='product' type='text' name='Artikelnummer' value='$Artikelnummer'>  
                        </span>
                            <br>
                        <span class='product_title'> fabrikantcode </span>
                        <span class='product_input'>
                           <input class='product' type='text' name='fabrikantcode' value='$fabrikantcode'>  
                        </span>
                          <br>
                        <span class='product_title'> merk </span>
                        <span class='product_input'> 
                             <input class='product_price' type='text' name='merk' value='$merk'>  
                        </span>
                          <br>
                     
                        <span class='product_title'> garantier</span>
                        <span class='product_input'> 
                           <input class='product_price' type='text' name='garantie' value='$garantie'>  
                        </span>
                           <br>
                        <span class='product_title'> garantietype</span>
                        <span class='product_input'>
                           <input class='product' type='text' name='garantietype' value='$garantietype'>  
                        </span>
                         <br>
                              <span class='product_title'> compatable_pc</span>
                          <span class='product_input'>
                           <input class='product' type='text' name='compatable_pc' value='$compatable_pc'>  
                        </span>
                         <br>
                              <span class='product_title'>compatable_smartphone</span>
                          <span class='product_input'>
                           <input class='product' type='text' name='compatable_smartphone' value='$compatable_smartphone'>  
                        </span>
                         <br>
                          <span class='product_title'> scherm</span>
                          <span class='product_input'>
                           <input class='product' type='text' name='scherm' value='$scherm'>  
                        </span>
                         <br>
                          <span class='product_title'> verversingssnelheid</span>
                          <span class='product_input'>
                           <input class='product' type='text' name='verversingssnelheid' value='$verversingssnelheid'>  
                        </span>
                         <br>
                          <span class='product_title'> gezichtsveld</span>
                          <span class='product_input'>
                           <input class='product' type='text' name='gezichtsveld' value='$gezichtsveld'>  
                        </span>
                         <br>
                          <span class='product_title'> verstelbaar</span>
                          <span class='product_input'>
                           <input class='product' type='text' name='verstelbaar' value='$verstelbaar'>  
                        </span>
                         <br>
                          <span class='product_title'> speakers</span>
                          <span class='product_input'>
                           <input class='product' type='text' name='speakers' value='$speakers'>  
                        </span>
                         <br>
                          <span class='product_title'> rotatie_tracking</span>
                          <span class='product_input'>
                           <input class='product' type='text' name='rotatie_tracking' value='$rotatie_tracking'>  
                        </span>
                         <br>
                          <span class='product_title'> positie_tracking</span>
                          <span class='product_input'>
                           <input class='product' type='text' name='positie_tracking' value='$positie_tracking'>  
                        </span>
                         <br>
                          <span class='product_title'> kamergrote_tracking</span>
                          <span class='product_input'>
                           <input class='product' type='text' name='kamergrote_tracking' value='$kamergrote_tracking'>  
                        </span> 
                        <br>
                          <span class='product_title'> controller_inbegrepen</span>
                          <span class='product_input'>
                           <input class='product' type='text' name='controller_inbegrepen' value='$controller_inbegrepen'>  
                        </span>
                         <br>
                          <span class='product_title'> motion_control</span>
                          <span class='product_input'>
                           <input class='product' type='text' name='motion_control' value='$motion_control'>  
                        </span>
                         <br>
                          <span class='product_title'> haptic_feedback</span>
                          <span class='product_input'>
                           <input class='product' type='text' name='haptic_feedback' value='$haptic_feedback'>  
                        </span>
                         <br>
                          <span class='product_title'> brill_vriendelijk</span>
                          <span class='product_input'>
                           <input class='product' type='text' name='brill_vriendelijk' value='$brill_vriendelijk'>  
                        </span>
                         <br>
                          <span class='product_title'> oogkussen</span>
                          <span class='product_input'>
                           <input class='product' type='text' name='oogkussen' value='$oogkussen'>  
                        </span>
                         <br>
                          <span class='product_title'> vervangbaar_oogkussen</span>
                          <span class='product_input'>
                           <input class='product' type='text' name='vervangbaar_oogkussen' value='$vervangbaar_oogkussen'>  
                        </span>
                         <br>
                          <span class='product_title'> hoofdband</span>
                          <span class='product_input'>
                           <input class='product' type='text' name='hoofdband' value='$hoofdband'>  
                        </span>
                         <br>

            
                         
                    </div> 
             
            
            <hr class='color_bottom'>";
    }

}


function products_upload($conn)
{
    $product_name           =  $_POST['product_name'];
    $product_price          = $_POST['product_price'];
    $product_description    = $_POST['product_desc'];
    $product_image          = basename($_FILES['product_image']['name']);
    $product_stock          = $_POST['product_stock'];
    $product_sale           = $_POST['product_sale'];
    $product_sale_price     = $_POST['product_sale_price'];
    if  (isset($product_sale)) {$product_sale = 1;} else {$product_sale = 0;}
    $last_id = "";
    $targetDir = "image/";
    $target_file = $targetDir . $product_image;
    $uploadOk = 1;
    $imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
    $error = "";
    $Artikelnummer     = $_POST['Artikelnummer'];
    $fabrikantcode     = $_POST['fabrikantcode'];
    $merk     = $_POST['merk'];
    $garantie     = $_POST['garantie'];
    $garantietype     = $_POST['garantietype'];
    $compatable_pc     = $_POST['compatable_pc'];
    $compatable_smartphone     = $_POST['compatable_smartphone'];
    $scherm     = $_POST['scherm'];
    $verversingssnelheid     = $_POST['verversingssnelheid'];
    $gezichtsveld     = $_POST['gezichtsveld'];
    $verstelbaar     = $_POST['verstelbaar'];
    $speakers     = $_POST['speakers'];
    $rotatie_tracking     = $_POST['rotatie_tracking'];
    $positie_tracking     = $_POST['positie_tracking'];
    $kamergrote_tracking     = $_POST['kamergrote_tracking'];
    $controller_inbegrepen       = $_POST['controller_inbegrepen'];
    $motion_control     = $_POST['motion_control'];
    $haptic_feedback     = $_POST['haptic_feedback'];
    $brill_vriendelijk     = $_POST['brill_vriendelijk'];
    $oogkussen     = $_POST['oogkussen'];
    $vervangbaar_oogkussen     = $_POST['vervangbaar_oogkussen'];
    $hoofdband     = $_POST['hoofdband'];

// Check if image file is a actual image or fake image
    $check = getimagesize($_FILES["product_image"]["tmp_name"]);
    if($check !== false) {
        echo "";
        $uploadOk = 1;
    } else {
        $error .=  "Je geuploade afbeelding is geen afbeelding.";
        $uploadOk = 0;
    }

    if (file_exists($target_file)) {
        $error .=  "Sorry, afbeelding naam bestaat al.";
        $uploadOk = 0;
    }
    // Check file size
    if ($_FILES["product_image"]["size"] > 500000) {
        $error .=  "Sorry, je afbeelding is te groot.";
        $uploadOk = 0;
    }
    // Allow certain file formats
    if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
        && $imageFileType != "gif" ) {
        $error .=  "Sorry, aleen JPG, JPEG, PNG & GIF afbeeldingen zijn toegestaan.";
        $uploadOk = 0;
    }
    // Check if $uploadOk is set to 0 by an error
    if ($uploadOk == 0) {
        $error .=  "Sorry, je afbeelding is niet geupload.";
// if everything is ok, try to upload file
    } else {
        if (move_uploaded_file($_FILES["product_image"]["tmp_name"], $target_file)) {
            echo "";
        } else {
            $error .=  "Sorry, het uploaden heeft een error genereerd. Uploaden mislukt.";
        }
    }
    if ($uploadOk == 1){
    $product_upload_insert = "INSERT INTO catalog (id,name,price,description,image,stock,sale,sale_price) 
                      VALUES ('NULL','$product_name','$product_price','$product_description','$product_image','$product_stock','$product_sale','$product_sale_price')";
    $product_upload_result = mysqli_query($conn, $product_upload_insert) or die(mysqli_error($conn));

    $last_id = mysqli_insert_id($conn);

    $product_specs_upload_insert = "INSERT INTO specs (id,product_id,Artikelnummer,fabrikantcode,merk,garantie,garantietype,compatable_pc,compatable_smartphone,scherm,verversingssnelheid,gezichtsveld,verstelbaar,speakers,rotatie_tracking,positie_tracking,kamergrote_tracking,controller_inbegrepen,motion_control,haptic_feedback,brill_vriendelijk,oogkussen,vervangbaar_oogkussen,hoofdband) 
                      VALUES ('NULL','$last_id','$Artikelnummer','$fabrikantcode','$merk','$garantie','$garantietype','$compatable_pc','$compatable_smartphone','$scherm','$verversingssnelheid','$gezichtsveld','$verstelbaar','$speakers','$rotatie_tracking','$positie_tracking','$kamergrote_tracking','$controller_inbegrepen','$motion_control','$haptic_feedback','$brill_vriendelijk','$oogkussen','$vervangbaar_oogkussen','$hoofdband')";
        $product_specs_upload_result = mysqli_query($conn, $product_specs_upload_insert) or die(mysqli_error($conn));

        $last_id_2 = mysqli_insert_id($conn);

    }
    else {  echo "Uploaden is niet goed gegaan";}

    if (!empty($last_id)) {
        echo "Product upload is goed geggaan";
        echo $error;
    } else {
        echo "Uploaden is niet goed gegaan";
        echo $error;
    }
}

function one_product_update($conn,$product_id, $product_name,$product_sale, $product_price, $product_desc, $product_image, $product_stock,$product_sale_price,$img_backup )
{
    $error ="";

if (!empty($product_image)){
    $targetDir = "image/";
    $target_file = $targetDir . $product_image;
    $uploadOk = 1;
    $imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));

// Check if image file is a actual image or fake image
    $check = getimagesize($_FILES["product_image"]["tmp_name"]);
    if($check !== false) {
        echo "";
        $uploadOk = 1;
    } else {
        $error .=  "Je geuploade afbeelding is geen afbeelding.";
        $uploadOk = 0;
    }

    if (file_exists($target_file)) {
        $error .=  "Sorry, afbeelding naam bestaat al.";
        $uploadOk = 0;
    }
    // Check file size
    if ($_FILES["product_image"]["size"] > 500000) {
        $error .=  "Sorry, je afbeelding is te groot.";
        $uploadOk = 0;
    }
    // Allow certain file formats
    if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
        && $imageFileType != "gif" ) {
        $error .=  "Sorry, aleen JPG, JPEG, PNG & GIF afbeeldingen zijn toegestaan.";
        $uploadOk = 0;
    }
    // Check if $uploadOk is set to 0 by an error
    if ($uploadOk == 0) {
        $error .=  "Sorry, je afbeelding is niet geupload.";
// if everything is ok, try to upload file
    } else {
        if (move_uploaded_file($_FILES["product_image"]["tmp_name"], $target_file)) {
            echo "";
        } else {
            $error .=  "Sorry, het uploaden heeft een error genereerd. Uploaden mislukt.";
        }
    }
}
else { $product_image = $img_backup;}
    if ($error == ""){
    $product_upload_insert = "UPDATE Catalog 
                              SET name = '$product_name',
                                  price = '$product_price', 
                                  description = '$product_desc',
                                  image = '$product_image', 
                                  stock = '$product_stock',
                                  sale= '$product_sale',
                                  sale_price = '$product_sale_price'
                              WHERE id = '$product_id'";


    $product_upload_result = mysqli_query($conn, $product_upload_insert) or die(mysqli_error($conn));
        $last_id = mysqli_insert_id($conn);
    }


    if (!empty($last_id)) {

        echo $error;
    } else {

        echo $error;
    }
}


//company info front

function company_info($conn)
{

    $company_title_sql = "SELECT * FROM company";
    $company_title_result = mysqli_query($conn, $company_title_sql) or die(mysqli_error($conn));

    $company_title_array = mysqli_fetch_array($company_title_result);
    $name = $company_title_array['company_name'];
    $description = $company_title_array['company_desc'];
    $company_street = $company_title_array['company_street'];
    $company_number = $company_title_array['company_number'];
    $company_zip = $company_title_array['company_zip'];
    $company_city = $company_title_array['company_city'];
    $company_state = $company_title_array['company_state'];
    $company_land = $company_title_array['company_land'];


    echo " <span class='company_info'> $name : $description </span> <br>";
    echo " <span class='company_info'> $company_street $company_number </span> <br>";
    echo " <span class='company_info'> $company_zip $company_city  </span> <br>";
    echo " <span class='company_info'> $company_state </span> <br>";
    echo " <span class='company_info'> $company_land </span> <br>";


}
//company info back
function company_info_backend($conn)
{

    $company_title_sql = "SELECT * FROM company";
    $company_title_result = mysqli_query($conn, $company_title_sql) or die(mysqli_error($conn));

    $company_title_array = mysqli_fetch_array($company_title_result);
    $name = $company_title_array['company_name'];
    $description = $company_title_array['company_desc'];
    $company_street = $company_title_array['company_street'];
    $company_number = $company_title_array['company_number'];
    $company_zip = $company_title_array['company_zip'];
    $company_city = $company_title_array['company_city'];
    $company_state = $company_title_array['company_state'];
    $company_land = $company_title_array['company_land'];

    echo "
    
      <div class='product_container'>
                        <span class='product_title'> Bedrijfs  Naam </span>
                        <span class='product_input'>
                           <input class='product' type='text' name='company_name' value='$name'>  
                        </span>
                            <br>
                        <span class='product_title'> Bedrijfs omschrijving </span>
                        <span class='product_input'> 
                            <textarea class='product' name='company_desc'>$description</textarea>  
                        </span>
                          <br>
                        <span class='product_title'> Bedrijfs straat </span>
                        <span class='product_input'> 
                             <input class='product_price' type='text' name='company_street' value='$company_street'>  
                        </span>
                          <br>
                     
                        <span class='product_title'> Bedrijfs nummer</span>
                        <span class='product_input'> 
                           <input class='product_price' type='text' name='company_number' value='$company_number'>  
                        </span>
                           <br>
                        <span class='product_title'> Bedrijfs postcode</span>
                        <span class='product_input'>
                           <input class='product' type='text' name='company_zip' value='$company_zip'>  
                        </span>
                         <br>
                              <span class='product_title'> Bedrijfs stad</span>
                          <span class='product_input'>
                           <input class='product' type='text' name='company_city' value='$company_city'>  
                        </span>
                         <br>
                              <span class='product_title'> Bedrijfs provincie</span>
                          <span class='product_input'>
                           <input class='product' type='text' name='company_state' value='$company_state'>  
                        </span>
                         <br>
                          <span class='product_title'> Bedrijfs land</span>
                          <span class='product_input'>
                           <input class='product' type='text' name='company_land' value='$company_land'>  
                        </span>
                         
                    </div>  ";

}
//company info update
function company_info_update($conn,$name,$description,$company_street,$company_number,$company_zip,$company_city,$company_state,$company_land)
{
    $company_upload_insert = "UPDATE company 
                              SET company_name = '$name', 
                                  company_desc = '$description', 
                                  company_street = '$company_street',
                                  company_number = '$company_number', 
                                  company_zip = '$company_zip',
                                  company_city = '$company_city',
                                  company_state = '$company_state',
                                  company_land = '$company_land'
                          WHERE company_id = '1'";

    $company_upload_result = mysqli_query($conn, $company_upload_insert) or die(mysqli_error($conn));


}
?>